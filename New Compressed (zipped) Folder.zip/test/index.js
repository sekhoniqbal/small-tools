var pronounce = require("./pronounce");
pronounce("elephant").then(result=>console.log(result))
