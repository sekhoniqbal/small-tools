var axios = require("axios");
var {parse} = require("node-html-parser")
//var Dictionary = require("oxford-dictionary-api");
//var   app_id = "50a427ed";
//var   app_key = "c7438ab5d763bb6b477d2057947ac6cc";
//var dict = new Dictionary(app_id, app_key);
//function find(word){
  //dict.find(word,function(error,data){if(error) return console.log(error); console.log(data); });
//}

//using cambridge Dictionary
async function pronounce(word){
baseurl = "https://dictionary.cambridge.org/dictionary/english/";
url = baseurl+word;
return axios.get(url)
.then(res=>res.data)
.then(res=>parse(res))
.then(dom=>dom.querySelector(".pron .ipa").innerHTML)
.catch(console.log.bind(console))
}

module.exports = pronounce;
